# SS Aurelian · physical-detail refinement checkpoint

**Status: revised editable model and matching GAME/import kit rebuilt and checked. The 25-view curated visual review is complete with explicit limits; the full evidence refresh/review remains in progress. This is not a completed strict visual release, user aesthetic approval or a Roblox Studio-certified playable ship.**

The appearance of published `6a9ee98` was judged insufficient despite its technical coverage. All **256 baseline images** were critically re-inspected, then the actual generator and geometry were revised—not just the lighting, camera filters or captions. See [DETAIL_REFINEMENT.md](DETAIL_REFINEMENT.md), the [256-image critical inventory](DETAIL_REVIEW.json) and the current [source-bound detail audit](DETAIL_GEOMETRY_AUDIT.json).

The exact earlier [build-12 delivery report](inspection/BUILD12_DELIVERY_REPORT.md) and [47-pass validation](inspection/BUILD12_DELIVERY_VALIDATION.json) are preserved separately. The 225-image progress report/snapshot is also unchanged. Those results belong to their recorded sources, **not** this refinement.

## 1. Changes in the actual model

* **Different public-room plans:** sixteen six-place first-dining groups with a service cross aisle; eight crosswise second-dining tables; a shared library reading table, end alcoves and low bookcases; perimeter writing secretaires and plum seating; separate billiards/cards/conversation in smoking; an open 85-key grand and piano-facing music seating; oak/blue games and newspaper groups in the second lounge.
* **Cabin identities:** five coordinated first-class wood/textile schemes, dressed berths, fitted shelves/books, wall reading lamps, under-berth cases and washing accessories. Second/officer/crew accommodation uses restrained role-specific finishes and stowage. Bunk ladders now have floor-supported stiles, five connected rungs and brackets into both berth frames; isolated rungs found in pilot views were corrected.
* **Proper working rooms:** cleanable painted/tiled finishes, utility workbenches rather than office desks, separate bread ovens/kneading/loaves/flour bin/peel, stocked pantry/mail/bar fittings, hospital iron beds and supported privacy screen, opaque barber-mirror bays and mounted notices.
* **Supported joinery and lighting:** actual ceiling/beam backplates and room-appropriate short fittings; six low fittings found by the clearance check were shortened. Real window reveals/sills/catches and bracketed curtains; cased secondary exits. Rails butt between stiles instead of overlapping coplanar corner faces; the black corner artefacts in pilot images were removed in geometry. Picture/instrument UVs are upright.
* **Stairs and plant:** risers, full brass nosings, closed stepped skirts with explicitly triangulated conforming caps and landing-guard feet; supported workshop bench, fastened plant identification, bearing oil cups and pipe hangers. The first revised GAME audit found 12 unpaired Grand_Main skirt edges; these were fixed, not waived. Hull, crank/rods, shaft, propeller and contracted machinery datums remain unchanged.
* **Exterior:** crowned/eaved deckhouse roofs, fascia, clipped finite weather planks, continuous rail-post rhythm, promenade benches with sole plates, top-rail-hooked lifebuoy brackets with **four finite grab-rope bridles per buoy**, supported bucket rack and navigation lights. All 38 standing cable feet have real chainplates; funnel ends meet clamp bands and long stays lead outboard, not through cabin roofs. The bridge clock/bell fasten to an opaque corner. The three contracted boat sockets remain unchanged; no other agent's boat or port asset is modified.
* **Exterior climbing access:** three mast ladders now have continuous rails, pole-clamp/T-bracket supports and carrier soles; both funnel ladders have actual shell stand-offs. The mizzen climbing frame starts on the crowned roof instead of passing through it. Separately emitted frame/rung meshes permit independent contact tests. Nest-platform access openings and live climbing are not implemented; no load rating is certified.
* **Original materials:** a full 64-tile 8×8 authored atlas, including quieter timber, herringbone, coordinated textiles/walls, instrument faces and notices. Geometry is not replaced with generated concept imagery.

## 2. Current measured assets

All current generated identities below use editable-master SHA-256:

`ddf84c2e8857dbd9f664e2c33108b955945c193ca219e1da5ad28b9b71946ead`

| Item | Current result |
|---|---:|
| Editable master | 1,432 mesh objects / **3,930,704 triangles** |
| Physical-space inventory | 203 |
| GAME visual nodes | 1,447, excluding four calibration nodes |
| Unique GAME meshes / reused placements | 1,029 / 418 |
| GAME placed / unique geometry triangles | 2,848,324 / 2,625,260 |
| Maximum triangles in one visual node | 18,000 |
| Complementary regional GLBs | 21 |
| Native collision proxies / doors / moving assemblies | 4,035 / 196 / 20 |
| Native seat locations / modeled light positions | 201 + helm VehicleSeat / 485 |
| Main stairs / engine ladders | 13 / 4 |
| Compacted native source | 22,120,515 bytes |
| Import archive | **25,196,272 bytes** |

Import archive SHA-256: `7c3562a97ab56d5d9271321b65d5ffe5e750a3d0710e932527d8176c881c5176`.

The new model is more detailed than build 12. Lower angular tessellation, reuse, spatial meshes and local detail/light budgets are supplied, but **no acceptable Roblox FPS is claimed**. The installer limits active nearby lights; the source count is not the simultaneously enabled count.

The source's native Zstandard stream was recompressed losslessly and its **210,942,956 decompressed bytes hash-compared** before replacement; no mesh, map or data was removed. [BLEND_COMPACTION.json](BLEND_COMPACTION.json) records the identities. The kit uses a 64MiB XZ dictionary to reuse identical embedded images across regional GLBs. It contains normal, hash-verified GLBs, not Draco or a newly decimated substitute. Source maps remain 2048²; embedded regional images use the already-documented 1024² mip level.

## 3. Executed checks on this source

| Scope | Executed result | Boundary |
|---|---|---|
| Actual detail contacts/layout | **7 PASS:** 286 ceiling/backplate rays, prefab envelopes/overlap screens, non-table fixture-bottom limit, 38 chainplate/deck contacts and 38 unobstructed standing-cable centre-lines, plus 330 exterior ladder rung ends and 44 frame/carrier interfaces across all five ladders | Not every hidden part contact, finite-radius rigging clearance, door sweep or continuous avatar route. |
| Actual-shell/stern/propeller regression | **3 PASS / 0 FAIL** | Analytical envelope plus lower-shell rays/contact graph and conservative screw-sweep bounds; not universal Boolean containment, strength or hydrodynamics. |
| Full source/current-GAME static checks | **20 PASS / 3 INFO / 1 UNVERIFIED** | Simplified collision grids/open doors/sampled stairs and machinery aisles; not Studio Humanoid walking. |
| Independent exact exported component audit | **1,029 unique meshes / 2,625,260 triangles / 96,568 components; all eight blocking categories zero** | No negative/near-zero component volume, opposing normals, degenerate area, odd unpaired edges, winding imbalance or collapsed edges. Coincident contacts are separately reported, not a two-manifold union or no-intersection guarantee. |
| Official Khronos format check | **21 regional GLBs, 0 errors / 0 warnings / 284 informational messages** | Actual regional hashes; not Studio upload/appearance acceptance. |
| Luau bytecode compilation | **6 / 6 PASS** | Compilation, not Roblox API/engine certification. |
| Exact-source runtime logic harness | **30 PASS** | Deliberately fake Roblox API: interlocks/transforms/prompt logic; no physics, replication, real LOS, streaming or frame-time test. |
| Strict complete-delivery checkpoint | **47 PASS / 5 FAIL / 1 UNVERIFIED — intentionally not accepted** | The current manual-review source and its 20 opened main image identities are valid. Five gates still reject incomplete main/survey evidence, missing current supplementary evidence, incomplete full manual coverage, missing supplementary manual review, and the explicitly IN_PROGRESS full-review status/blocker. The curated 25-view subset cannot satisfy those gates. Studio/live/FPS remains unverified. |

Reports: [DETAIL_GEOMETRY_AUDIT.json](DETAIL_GEOMETRY_AUDIT.json), [STRUCTURE_GEOMETRY_AUDIT.json](STRUCTURE_GEOMETRY_AUDIT.json), [STATIC_VALIDATION.json](STATIC_VALIDATION.json), [COMPONENT_VOLUME_AUDIT.json](COMPONENT_VOLUME_AUDIT.json), [GLTF_VALIDATION.json](GLTF_VALIDATION.json), [LUAU_COMPILE.json](LUAU_COMPILE.json), [RUNTIME_LOGIC_TESTS.json](RUNTIME_LOGIC_TESTS.json), [DELIVERY_VALIDATION.json](DELIVERY_VALIDATION.json).

The new independent ladder gate also has executed isolated positive/negative regressions: **3 PASS in MASTER detail and 3 PASS in GAME detail**. A 150mm-displaced existing frame fails the actual rung-contact rays; a removed frame is separately rejected. These [MASTER](LADDER_AUDIT_REGRESSION_MASTER.json) / [GAME](LADDER_AUDIT_REGRESSION_GAME.json) reports concern a generated fixture subset, not a second whole-ship/Studio certificate. Reproduce serially with `tools/test_leonidas_ladders.py` under Blender, once normally and once with `LII_GAME_DETAIL=1`.

Export normal/precision handling retains 57 original source-precision vertices and corrects 14,190 shading corners across placements without changing authored form. The corrected export removes **zero** zero-area source triangles; the earlier concave stair-cap failure was repaired at source.

## 4. Visual evidence status — no old-image relabelling

The earlier **25-view / 1120×700 pilot was completed and every final JPG individually opened**; its exact [archived review](inspection/DETAIL_PILOT_REVIEW.json) records two remaining corrections, not final approval. The grab rope now has four finite geometry bridles per buoy, and the actual furniture-clear wheelhouse camera was moved to face the telegraph dials and supported clock/bell corner. The corrected master, GAME and kit were rebuilt and rechecked under the new source hash above.

**The final [self-contained curated gallery](DETAIL_REFINEMENT.html) is now complete:** **19 full-resolution 1600×1000 interior JPGs from the main run + six 1120×700 / 24-sample exterior diagnostics**, each individually opened and bound to the exact master, renderer, audit and image hashes in [DETAIL_VISUAL_REVIEW.json](DETAIL_VISUAL_REVIEW.json). It reuses no pilot pixels or enlarged interiors. The further-aft wheelhouse camera exposes both dial faces and the clock/bell corner in the opened full-resolution main JPG; the exposed buoy bridle is visible in the fresh close-up, while occluded ties/hooks remain a declared view limitation. The stair remains explicitly wall-removed.

Curated status is **`FOCUSED_REVIEW_COMPLETE_FULL_EVIDENCE_SEPARATE`**, not user aesthetic or playable-release acceptance. The durable [mixed camera register](../../renders/leonidas_ii/refinement/camera_register.json) references the 19 main interiors directly and six separate close-ups; it does not duplicate/replace the main views. The HTML has 25 embedded images and zero remote assets, and a real durable-register rerun is byte-identical. The helper also has 17 reproducible synthetic-fixture tests; those tests review no real image. Renderer SHA-256: `f65539e02551d45852cc9faa22d209477f6aa02918d2093c6d65215ec79c2142`.

At this checkpoint the separate full manual review has **20/51 major JPGs individually opened, 0/203 current room-survey panels and 0/2 current supplementary views**, plus three reopened exact analytical SVG rasterisations. The full serial job continues through the remaining service/engineering/exterior/deck views, surveys and crew details. The original public/accommodation finals and the six selected service majors are retained by exact-pose/source/renderer/sample resume checks, not relabelled old pixels.

The original 256 images are being replaced **only by newly rendered matching-source pixels** as the serial run completes. Until the full refresh/gallery/manual review finishes, the retained [historical embedded gallery](EVIDENCE_INDEX.html) still describes published `6a9ee98` and now carries a prominent warning; all 256 old embedded thumbnail bytes are unchanged, but loose disk images are being replaced and must not be confused with that baseline. The original [published visual register](inspection/BUILD12_VISUAL_REVIEW.json) is preserved byte-for-byte, while [VISUAL_REVIEW.json](VISUAL_REVIEW.json) now honestly records the current in-progress inspection (including freshly reopened conventional rasterisations of the three exact analytical SVGs). Neither stale review nor mixed in-progress file presence validates this changed master. Do not assign the new hash to old pixels. The full planned evidence remains **51 major views + 203 roof-off compartment surveys**, plus two explicit wall/roof-removed crew-mess diagnostics. Enclosed photographs, roof-off surveys, technical cutaways and analytical drawings remain distinct.

Cycles staging uses actual registered fixture points plus photographic fill, two diffuse/glossy bounces and a temporary 1K texture cache. Conventional OIDN/JPEG processing is recorded. Delivered 2K maps are not overwritten; residual noise/softness and visibility limits must be recorded per view. There are no synthetic gameplay screenshots or historical-photo claims.

## 5. Preserved envelope, capacity and live limitations

* Fictional **1889 British Atlantic passenger/mail/cargo liner**, Liverpool–Queenstown–New York: **166m LOA / 158m LBP / 18.4m moulded beam / 6.5m design draft**, nine boilers, two funnels, three pole masts, single screw. Not an actual historical Aurelian or a literal Teutonic reconstruction.
* Shared scale **0.28m/stud**; 592.857 × 65.714 × 23.214 studs. Source +X bow / +Y port / +Z baseline; GLB **metres**, `(-y, z−6.5, -x)`, waterline origin. Four genuine 10m calibration markers establish scale once.
* **628 passenger positions:** 228 first / 132 second / 268 third, plus **117 crew berths**. First class is **114 permanent beds + 114 modeled convertible settee positions**; live conversion/sleeping is unimplemented. Dining stays **96 / 48 actual seats**. The 900/196 planning targets are not achieved.
* Engine bores 1.4 / 2.25 / 3.5m, 1.8m stroke; nominal 72rpm and about 19.3kn are gameplay kinematics, not proven power/resistance/coal use or sea speed. No stability, scantling, pressure-vessel or seaworthiness certification.
* Three compatible boat sockets are not an eleven-boat lifesaving inventory. Boat/port work is a unilateral interface handoff, not joint acceptance. Quay/gangway/channel/launch/hoist world fit remains untested.
* Implemented installer/runtime contracts cover regional calibration, anchored root/movers, interlocks, signed engine orders, doors, helm, seating, prototype standing carry and local detail/light budgets. **No Studio import, continuous Humanoid access, multiplayer carry/security, streaming or measured FPS acceptance has occurred.**

## 6. Files, rebuild and publication

* Current limited-scope visual handoff: [DETAIL_REFINEMENT.html](DETAIL_REFINEMENT.html), [manual observations](DETAIL_VISUAL_REVIEW.json) and `renders/leonidas_ii/refinement/camera_register.json`.
* Editable source: `models/leonidas_ii/Aurelian_1889.blend`; generator in `blender/leonidas_ii/` and stable vessel contract in `shipdesign/leonidas_ii.py`.
* Matching import kit: `exports/leonidas_ii/Aurelian_Roblox_Import_Kit.tar.xz`; six current Luau sources and insertable `.rbxmx` in `roblox/leonidas_ii/`.
* Installation/live checklist: [ROBLOX_INSTALL_AND_TEST.md](ROBLOX_INSTALL_AND_TEST.md). Extract the archive before importing. Uploaded content IDs and a finished Roblox place are not supplied.
* Design/provenance: [DESIGN_AND_SOURCES.md](DESIGN_AND_SOURCES.md), [ATTRIBUTION.md](ATTRIBUTION.md), [previous-generation inspection](PREVIOUS_GENERATION_INSPECTION.md). No newly discovered historical plans are claimed.
* Rebuild serially with Blender 4.2 LTS and the external Python dependencies in `blender/leonidas_ii/requirements.txt`, now including `zstandard`: `bash tools/build_leonidas_ii.sh`. Follow the README for Khronos/Luau checks, render batches and manual review. Do not rerun the one-off `tools/leonidas_revision_fixes.py` migration.

Branch **`agent/leonidas-ii`**, published HEAD **`6a9ee980fc9876b691dbb1f7535b61f619b181ed`**. This refinement is currently an **uncommitted/unpublished working-tree revision**. The preserved publication receipt and 225-image progress snapshot describe past commits only. No new push or finished acceptance is claimed. Full evidence/review gates must pass before a final publication; no force-push or other branch overwrite is authorized.
